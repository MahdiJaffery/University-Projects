#pragma once


using namespace System;

public ref class User {
public:
	int id;
	String^ name;
	String^ age;
	String^ cnic;
	String^ bloodgroup;
	String^ disease;
	String^ weight;
	String^ email;
	String^ phone;
	String^ password;
	String^ address;
};